#!/bin/bash
cd src
./build_t
./update-bin.sh