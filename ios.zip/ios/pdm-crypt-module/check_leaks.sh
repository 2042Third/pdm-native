#!/bin/bash
leaks -atExit -- ./build/c20wrap