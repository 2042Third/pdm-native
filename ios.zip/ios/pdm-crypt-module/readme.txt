Need fixing, seg fault on all platforms
