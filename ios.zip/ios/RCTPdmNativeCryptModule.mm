#import "RCTPdmNativeCryptModule.h"
#import <React/RCTLog.h>
#import <React/RCTUtils.h>
#import <React/RCTConvert.h>

#import <Foundation/Foundation.h>

//#ifdef __cplusplus

//#import "pdm-crypt-module/src/include/empp.h"
#import "empp.h"

//#endif

@implementation RCTPdmNativeCryptModule
// Export native 'PdmNativeCryptModule'
RCT_EXPORT_MODULE(PdmNativeCryptModule);

+ (BOOL)requiresMainQueueSetup
{
  return NO;
}

RCT_EXPORT_METHOD(echoer:( NSString*)a  callback: (RCTResponseSenderBlock)callback)
{
  RCTLogInfo(@"Pretending to create an event (this is from a objective-c++ module) %@", a);

  
  callback(@[@"from Objective-C++ .mm"]);
}

RCT_EXPORT_METHOD(getHash:( NSString*)a  callback: (RCTResponseSenderBlock)callback)
{
  
  callback(@[@(get_hash([a UTF8String]).c_str())]);
}

@end
