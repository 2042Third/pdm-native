#!/bin/bash

make en
mv c20 tests/