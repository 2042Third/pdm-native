#include "cc20_diff.h"

void cc20_diff::get_diff(const char * a, char * b){
  
}