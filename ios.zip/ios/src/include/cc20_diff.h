class cc20_diff {
public:
  void get_diff(const char* a, char* b);
private:

};