//
// Created by 18604 on 6/26/2022.
//

#ifndef CC20_MULTI_TYPES_H
#define CC20_MULTI_TYPES_H

#include <cstdint>
#include <vector>

typedef std::vector<uint8_t> Bytes;
#endif //CC20_MULTI_TYPES_H
